package com.indirgec.app.download

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.indirgec.app.MainActivity
import com.indirgec.app.R
import com.indirgec.app.data.DownloadItem
import com.indirgec.app.data.Status

object Notifications {
    const val CH_PROGRESS = "downloads"
    const val CH_DONE = "done"
    const val ID_PROGRESS = 1001

    fun createChannels(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_PROGRESS, "İndirmeler", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_DONE, "Tamamlanan indirmeler", NotificationManager.IMPORTANCE_DEFAULT)
        )
    }

    private fun openApp(ctx: Context): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        return PendingIntent.getActivity(ctx, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun progress(ctx: Context, items: List<DownloadItem>): Notification {
        val cur = items.firstOrNull { it.status == Status.RUNNING }
        val queued = items.count { it.status == Status.QUEUED }
        val pct = ((cur?.progress ?: 0f) * 100).toInt().coerceIn(0, 100)
        val parts = ArrayList<String>()
        if (cur != null && cur.progress > 0f) parts += "%$pct"
        if (cur != null && cur.speed.isNotEmpty()) parts += cur.speed
        if (queued > 0) parts += "+$queued sırada"
        val b = NotificationCompat.Builder(ctx, CH_PROGRESS)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle(cur?.title ?: "İndirme hazırlanıyor…")
            .setContentText(if (parts.isEmpty()) "Başlatılıyor" else parts.joinToString(" • "))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(ctx))
            .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
            .setProgress(100, pct, cur == null || cur.progress <= 0f)
        if (cur != null) {
            val cancel = Intent(ctx, DownloadService::class.java)
                .setAction(DownloadService.ACTION_CANCEL)
                .putExtra(DownloadService.EXTRA_ID, cur.id)
            val pi = PendingIntent.getService(
                ctx, cur.id.hashCode(), cancel,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            b.addAction(android.R.drawable.ic_menu_close_clear_cancel, "İptal Et", pi)
        }
        return b.build()
    }

    fun done(ctx: Context, title: String, ok: Boolean) {
        try {
            val n = NotificationCompat.Builder(ctx, CH_DONE)
                .setSmallIcon(R.drawable.ic_stat_download)
                .setContentTitle(if (ok) "İndirme tamamlandı" else "İndirme başarısız")
                .setContentText(title)
                .setAutoCancel(true)
                .setContentIntent(openApp(ctx))
                .build()
            ctx.getSystemService(NotificationManager::class.java)
                .notify((System.nanoTime() % Int.MAX_VALUE).toInt(), n)
        } catch (e: Exception) {
        }
    }
}
