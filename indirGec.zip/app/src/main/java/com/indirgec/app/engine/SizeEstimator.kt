package com.indirgec.app.engine

import com.indirgec.app.data.MediaInfo
import com.indirgec.app.data.Quality

/** İndirme boyutu tahmini (bayt). Gerçek format boyutu varsa onu, yoksa süre x ortalama bit hızını kullanır. */
object SizeEstimator {
    private fun rateKbps(q: Quality): Int = when (q) {
        Quality.BEST -> 3500
        Quality.P1080 -> 3000
        Quality.P720 -> 1500
        Quality.P480 -> 800
        Quality.MP3_192 -> 192
        Quality.MP3_320 -> 320
        Quality.M4A -> 128
    }

    fun byDuration(durationSec: Long, q: Quality): Long =
        if (durationSec <= 0) 0L else durationSec * rateKbps(q) * 125L

    private fun sizeOf(f: com.indirgec.app.data.FormatInfo, dur: Long): Long = when {
        f.sizeBytes > 0 -> f.sizeBytes
        f.tbr > 0 && dur > 0 -> (f.tbr * 125.0 * dur).toLong()
        else -> 0L
    }

    fun estimate(info: MediaInfo, q: Quality): Long {
        val dur = info.durationSec
        if (q == Quality.MP3_192 || q == Quality.MP3_320) return byDuration(dur, q)
        val audioBest = info.formats.filter { it.hasAudio && !it.hasVideo }.maxByOrNull { it.tbr }
        if (q == Quality.M4A) {
            val s = if (audioBest != null) sizeOf(audioBest, dur) else 0L
            return if (s > 0) s else byDuration(dur, q)
        }
        val maxH = when (q) {
            Quality.P1080 -> 1080
            Quality.P720 -> 720
            Quality.P480 -> 480
            else -> Int.MAX_VALUE
        }
        val videos = info.formats.filter { it.hasVideo && it.height in 1..maxH }
        val bestH = videos.maxOfOrNull { it.height }
        if (bestH != null) {
            val v = videos.filter { it.height == bestH }.maxByOrNull { it.tbr }
            if (v != null) {
                var total = sizeOf(v, dur)
                if (!v.hasAudio && audioBest != null) total += sizeOf(audioBest, dur)
                if (total > 0) return total
            }
        }
        return byDuration(dur, q)
    }
}
