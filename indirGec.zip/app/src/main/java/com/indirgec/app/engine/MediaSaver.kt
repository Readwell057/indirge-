package com.indirgec.app.engine

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException

/** Videoları Movies/VideoIndirici, sesleri Music/VideoIndirici klasörüne kaydeder. */
object MediaSaver {
    data class Saved(val uri: String, val mime: String, val name: String)

    private val audioExts = setOf("mp3", "m4a", "aac", "opus", "ogg", "wav", "flac")

    private fun mimeFor(ext: String): String = when (ext) {
        "mp4", "m4v" -> "video/mp4"
        "webm" -> "video/webm"
        "mkv" -> "video/x-matroska"
        "mov" -> "video/quicktime"
        "3gp" -> "video/3gpp"
        "mp3" -> "audio/mpeg"
        "m4a" -> "audio/mp4"
        "aac" -> "audio/aac"
        "opus", "ogg" -> "audio/ogg"
        "wav" -> "audio/wav"
        "flac" -> "audio/flac"
        else -> "video/mp4"
    }

    fun save(ctx: Context, file: File, audioRequested: Boolean): Saved {
        val ext = file.extension.lowercase()
        val isAudio = audioRequested || ext in audioExts
        val mime = mimeFor(ext)
        val name = file.name

        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = ctx.contentResolver
            val collection = if (isAudio)
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, if (isAudio) "Music/VideoIndirici" else "Movies/VideoIndirici")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = resolver.insert(collection, values) ?: throw IOException("MediaStore kaydı oluşturulamadı")
            try {
                val out = resolver.openOutputStream(uri) ?: throw IOException("Dosya yazılamadı")
                out.use { o -> file.inputStream().use { it.copyTo(o) } }
                val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                resolver.update(uri, done, null, null)
            } catch (t: Throwable) {
                try { resolver.delete(uri, null, null) } catch (e: Exception) { }
                throw t
            }
            return Saved(uri.toString(), mime, name)
        }

        // Android 7-9: doğrudan genel klasöre yaz
        val base = Environment.getExternalStoragePublicDirectory(
            if (isAudio) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
        )
        val dir = File(base, "VideoIndirici")
        dir.mkdirs()
        var target = File(dir, name)
        var i = 1
        while (target.exists()) {
            target = File(dir, "${file.nameWithoutExtension} ($i).${file.extension}")
            i++
        }
        file.copyTo(target, overwrite = false)
        MediaScannerConnection.scanFile(ctx, arrayOf(target.absolutePath), arrayOf(mime), null)
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", target)
        return Saved(uri.toString(), mime, target.name)
    }

    fun delete(ctx: Context, uriString: String) {
        try {
            ctx.contentResolver.delete(Uri.parse(uriString), null, null)
        } catch (e: Exception) {
        }
    }
}
