@file:OptIn(ExperimentalMaterial3Api::class)

package com.indirgec.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import com.indirgec.app.download.DownloadManager

private data class NavItem(val label: String, val icon: ImageVector)

@Composable
fun MainScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val snack = remember { SnackbarHostState() }
    val browser = remember { BrowserState(ctx) }
    DisposableEffect(Unit) { onDispose { browser.destroy() } }

    LaunchedEffect(vm.message) {
        val m = vm.message
        if (m != null) {
            vm.message = null
            snack.showSnackbar(m)
        }
    }

    val items by DownloadManager.items.collectAsState()
    val activeCount = items.count { it.isActive }
    val wide = LocalConfiguration.current.screenWidthDp >= 600
    val nav = listOf(
        NavItem("İndir", Icons.Filled.Download),
        NavItem("Tarayıcı", Icons.Filled.Language),
        NavItem("İndirmeler", Icons.Filled.History),
        NavItem("Ayarlar", Icons.Filled.Settings)
    )

    BackHandler(enabled = vm.tab != 0 && !(vm.tab == 1 && browser.canGoBack)) { vm.tab = 0 }

    @Composable
    fun NavIcon(i: Int) {
        val n = nav[i]
        if (i == 2 && activeCount > 0) {
            BadgedBox(badge = { Badge { Text("$activeCount") } }) { Icon(n.icon, n.label) }
        } else {
            Icon(n.icon, n.label)
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = {
            if (!wide) {
                NavigationBar {
                    nav.forEachIndexed { i, n ->
                        NavigationBarItem(
                            selected = vm.tab == i,
                            onClick = { vm.tab = i },
                            icon = { NavIcon(i) },
                            label = { Text(n.label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        Row(Modifier.padding(pad).fillMaxSize()) {
            if (wide) {
                NavigationRail {
                    nav.forEachIndexed { i, n ->
                        NavigationRailItem(
                            selected = vm.tab == i,
                            onClick = { vm.tab = i },
                            icon = { NavIcon(i) },
                            label = { Text(n.label) }
                        )
                    }
                }
            }
            Box(Modifier.weight(1f).fillMaxHeight()) {
                when (vm.tab) {
                    0 -> DownloadTab(vm)
                    1 -> BrowserTab(vm, browser)
                    2 -> DownloadsTab()
                    else -> SettingsTab(vm)
                }
            }
        }
    }
}
