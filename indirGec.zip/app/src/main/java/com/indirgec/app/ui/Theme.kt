package com.indirgec.app.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val BrandDark = darkColorScheme(
    primary = Color(0xFF4FC3F7),
    onPrimary = Color(0xFF00334A),
    secondary = Color(0xFFB388FF),
    tertiary = Color(0xFFFFB74D),
    background = Color(0xFF0B1426),
    surface = Color(0xFF111C33),
    surfaceVariant = Color(0xFF1B2A47),
    onBackground = Color(0xFFE6EDF7),
    onSurface = Color(0xFFE6EDF7)
)

private val BrandLight = lightColorScheme(
    primary = Color(0xFF0277BD),
    secondary = Color(0xFF6A3FD0),
    tertiary = Color(0xFFE65100)
)

@Composable
fun IndirGecTheme(theme: Int, dynamic: Boolean, content: @Composable () -> Unit) {
    val dark = when (theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    val scheme = when {
        dynamic && Build.VERSION.SDK_INT >= 31 ->
            if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> BrandDark
        else -> BrandLight
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
