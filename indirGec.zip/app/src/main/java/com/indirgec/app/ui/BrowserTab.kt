@file:OptIn(ExperimentalMaterial3Api::class)

package com.indirgec.app.ui

import android.view.ViewGroup
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

@Composable
fun BrowserTab(vm: MainViewModel, b: BrowserState) {
    var input by remember { mutableStateOf(b.currentUrl) }
    var showList by remember { mutableStateOf(false) }
    LaunchedEffect(b.currentUrl) { input = b.currentUrl }
    BackHandler(enabled = b.canGoBack) { b.webView.goBack() }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { if (b.webView.canGoBack()) b.webView.goBack() }, enabled = b.canGoBack) {
                Icon(Icons.Filled.ArrowBack, "Geri")
            }
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("Adres veya arama") },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
                keyboardActions = KeyboardActions(onGo = { b.load(input) })
            )
            IconButton(onClick = { b.webView.reload() }) { Icon(Icons.Filled.Refresh, "Yenile") }
            IconButton(onClick = {
                if (b.currentUrl.startsWith("http")) vm.onSharedText(b.currentUrl)
            }) { Icon(Icons.Filled.Download, "Bu sayfayı indir") }
        }

        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AssistChip(onClick = { b.load("https://m.youtube.com") }, label = { Text("YouTube") })
            AssistChip(onClick = { b.load("https://www.instagram.com") }, label = { Text("Instagram") })
            AssistChip(onClick = { b.load("https://x.com") }, label = { Text("X") })
            AssistChip(onClick = { b.load("https://www.tiktok.com") }, label = { Text("TikTok") })
        }

        if (b.progress in 1..99) {
            LinearProgressIndicator(progress = { b.progress / 100f }, modifier = Modifier.fillMaxWidth())
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                factory = {
                    (b.webView.parent as? ViewGroup)?.removeView(b.webView)
                    b.webView
                },
                modifier = Modifier.fillMaxSize()
            )
            if (b.captured.isNotEmpty()) {
                Card(Modifier.align(Alignment.BottomCenter).padding(12.dp).fillMaxWidth()) {
                    Row(
                        Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { vm.downloadCaptured(b.captured.last(), b.pageTitle) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Medya Yakalandı - İndir", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (b.captured.size > 1) {
                            TextButton(onClick = { showList = true }) { Text("${b.captured.size} akış") }
                        }
                    }
                }
            }
        }
    }

    if (showList) {
        AlertDialog(
            onDismissRequest = { showList = false },
            title = { Text("Yakalanan akışlar") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    b.captured.reversed().forEach { c ->
                        TextButton(onClick = {
                            showList = false
                            vm.downloadCaptured(c, b.pageTitle)
                        }) {
                            Text(
                                c.url,
                                maxLines = 2,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showList = false }) { Text("Kapat") } }
        )
    }
}
