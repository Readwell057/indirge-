package com.indirgec.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.getSharedPreferences("indirgec", Context.MODE_PRIVATE)
    }

    var useCookies: Boolean
        get() = sp.getBoolean("cookies", true)
        set(v) { sp.edit().putBoolean("cookies", v).apply() }

    var useAria2: Boolean
        get() = sp.getBoolean("aria2", false)
        set(v) { sp.edit().putBoolean("aria2", v).apply() }

    /** 0 = sistem, 1 = açık, 2 = koyu */
    var theme: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }

    var dynamicColor: Boolean
        get() = sp.getBoolean("dynamic", true)
        set(v) { sp.edit().putBoolean("dynamic", v).apply() }

    var history: String
        get() = sp.getString("history", "[]") ?: "[]"
        set(v) { sp.edit().putString("history", v).apply() }
}
