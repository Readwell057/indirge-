package com.indirgec.app.engine

import android.app.Application
import android.content.Context
import com.indirgec.app.Prefs
import com.indirgec.app.data.FormatInfo
import com.indirgec.app.data.MediaInfo
import com.indirgec.app.data.PlaylistEntry
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

object Engine {
    /** Gerçek Chrome (WebView değil) kimliği: Google girişi ve 403 engelleri için. */
    const val BROWSER_UA =
        "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/124.0.0.0 Mobile Safari/537.36"

    /** Tek bir deneme: hangi YouTube istemcisi (null = varsayılan) ve çerez kullanılsın mı. */
    data class Attempt(val client: String?, val cookies: Boolean)

    /**
     * Deneme sırası. YouTube'da önce ÇEREZSİZ denenir (WebView çerezleri bayatlayıp
     * "çerezler geçersiz" hatası verebilir), sonra çerezli, sonra alternatif istemciler.
     */
    fun attempts(url: String, hasCookies: Boolean): List<Attempt> {
        val l = ArrayList<Attempt>()
        if (isYoutube(url)) {
            l += Attempt(null, false)
            if (hasCookies) l += Attempt(null, true)
            l += Attempt("android_vr", false)
            l += Attempt("tv", false)
        } else {
            if (hasCookies) l += Attempt(null, true)
            l += Attempt(null, false)
        }
        return l
    }

    /** Tekrar denemenin anlamsız olduğu kesin hatalar. */
    fun isFinalError(t: Throwable): Boolean {
        val m = (t.message ?: "").lowercase()
        return listOf(
            "video unavailable", "private video", "has been removed", "copyright",
            "not available in your country", "members-only", "this video is not available"
        ).any { m.contains(it) }
    }

    fun pickError(errors: List<Throwable>): Throwable =
        errors.firstOrNull { isSignInError(it) } ?: errors.first()

    fun isYoutube(url: String): Boolean {
        val u = url.lowercase()
        return u.contains("youtube.com") || u.contains("youtu.be") || u.contains("youtube-nocookie.com")
    }

    fun isSignInError(t: Throwable): Boolean {
        val m = (t.message ?: "").lowercase()
        return m.contains("sign in") || m.contains("not a bot") || m.contains("login required")
    }

    fun origin(url: String): String? = try {
        val u = android.net.Uri.parse(url)
        if (u.scheme != null && u.host != null) "${u.scheme}://${u.host}/" else null
    } catch (e: Exception) {
        null
    }

    sealed interface State {
        object Loading : State
        object Ready : State
        data class Failed(val message: String) : State
    }

    private val _state = MutableStateFlow<State>(State.Loading)
    val state: StateFlow<State> = _state.asStateFlow()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    var aria2Available: Boolean = false
        private set

    fun start(app: Application) {
        _state.value = State.Loading
        scope.launch {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                try {
                    Aria2c.getInstance().init(app)
                    aria2Available = true
                } catch (e: Throwable) {
                    aria2Available = false
                }
                _state.value = State.Ready
            } catch (t: Throwable) {
                _state.value = State.Failed(t.message ?: t.javaClass.simpleName)
            }
        }
    }

    suspend fun awaitReady(): Boolean = state.first { it !is State.Loading } is State.Ready

    private fun notReadyMessage(): String =
        "İndirme motoru hazır değil: " + ((state.value as? State.Failed)?.message ?: "")

    fun version(ctx: Context): String? = try {
        YoutubeDL.getInstance().version(ctx)
    } catch (e: Throwable) {
        null
    }

    suspend fun update(ctx: Context): String = withContext(Dispatchers.IO) {
        if (!awaitReady()) throw IllegalStateException(notReadyMessage())
        val st = YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.NIGHTLY)
        if (st.toString().contains("ALREADY", ignoreCase = true)) "Motor zaten güncel" else "Motor güncellendi"
    }

    suspend fun fetchInfo(ctx: Context, url: String, referer: String? = null, ua: String? = null): MediaInfo = withContext(Dispatchers.IO) {
        if (!awaitReady()) throw IllegalStateException(notReadyMessage())
        val cookieFile = if (Prefs.useCookies) CookieWriter.write(ctx, listOfNotNull(url, referer)) else null
        try {
            val errors = ArrayList<Throwable>()
            for (a in attempts(url, cookieFile != null)) {
                try {
                    val req = YoutubeDLRequest(url)
                    req.addOption("--dump-single-json")
                    req.addOption("--flat-playlist")
                    req.addOption("--no-warnings")
                    if (!isYoutube(url)) {
                        req.addOption("--user-agent", ua ?: BROWSER_UA)
                        (referer ?: origin(url))?.let { req.addOption("--referer", it) }
                        referer?.let { r -> origin(r)?.let { o -> req.addOption("--add-header", "Origin:" + o.trimEnd('/')) } }
                    }
                    a.client?.let { req.addOption("--extractor-args", "youtube:player_client=$it") }
                    if (a.cookies && cookieFile != null) req.addOption("--cookies", cookieFile.absolutePath)
                    val resp = YoutubeDL.getInstance().execute(request = req)
                    return@withContext parse(url, resp.out)
                } catch (t: Throwable) {
                    if (t is CancellationException) throw t
                    errors += t
                    if (isYoutube(url) && isFinalError(t)) break
                }
            }
            throw pickError(errors)
        } finally {
            cookieFile?.delete()
        }
    }

    private fun JSONObject.str(k: String): String? {
        if (!has(k) || isNull(k)) return null
        val s = optString(k)
        return if (s.isBlank()) null else s
    }

    private fun thumb(o: JSONObject): String? {
        o.str("thumbnail")?.let { return it }
        val arr = o.optJSONArray("thumbnails") ?: return null
        for (i in arr.length() - 1 downTo 0) {
            val t = arr.optJSONObject(i) ?: continue
            t.str("url")?.let { return it }
        }
        return null
    }

    private fun parse(url: String, out: String): MediaInfo {
        val line = out.lineSequence().map { it.trim() }.lastOrNull { it.startsWith("{") }
            ?: throw IllegalStateException("Bağlantı hakkında bilgi alınamadı")
        val o = JSONObject(line)
        val uploader = o.str("uploader") ?: o.str("channel")

        if (o.optString("_type") == "playlist" || o.has("entries")) {
            val arr = o.optJSONArray("entries")
            val entries = ArrayList<PlaylistEntry>()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val e = arr.optJSONObject(i) ?: continue
                    var eu = e.str("url") ?: e.str("webpage_url") ?: continue
                    if (!eu.startsWith("http")) {
                        eu = if (e.optString("ie_key").equals("Youtube", true))
                            "https://www.youtube.com/watch?v=$eu" else continue
                    }
                    val ed = if (e.isNull("duration")) 0L else e.optDouble("duration", 0.0).toLong()
                    entries += PlaylistEntry(eu, e.str("title") ?: eu, thumb(e), ed)
                }
            }
            return MediaInfo(
                url = url,
                title = o.str("title") ?: "Oynatma listesi",
                thumbnail = thumb(o) ?: entries.firstOrNull()?.thumbnail,
                uploader = uploader,
                durationSec = 0,
                heights = emptyList(),
                isPlaylist = true,
                entries = entries
            )
        }

        val heights = LinkedHashSet<Int>()
        val fl = ArrayList<FormatInfo>()
        val fmts = o.optJSONArray("formats")
        if (fmts != null) {
            for (i in 0 until fmts.length()) {
                val f = fmts.optJSONObject(i) ?: continue
                val h = if (f.isNull("height")) 0 else f.optInt("height", 0)
                if (h > 0) heights += h
                val size = when {
                    !f.isNull("filesize") -> f.optLong("filesize", 0)
                    !f.isNull("filesize_approx") -> f.optDouble("filesize_approx", 0.0).toLong()
                    else -> 0L
                }
                val tbr = if (f.isNull("tbr")) 0.0 else f.optDouble("tbr", 0.0)
                fl += FormatInfo(h, f.optString("vcodec") != "none", f.optString("acodec") != "none", size, tbr)
            }
        }
        return MediaInfo(
            url = url,
            title = o.str("title") ?: o.str("fulltitle") ?: "video",
            thumbnail = thumb(o),
            uploader = uploader,
            durationSec = if (o.isNull("duration")) 0 else o.optLong("duration", 0),
            heights = heights.toList(),
            isPlaylist = false,
            entries = emptyList(),
            formats = fl
        )
    }
}
