package com.indirgec.app.engine

import android.app.Application
import android.content.Context
import com.indirgec.app.Prefs
import com.indirgec.app.data.MediaInfo
import com.indirgec.app.data.PlaylistEntry
import com.yausername.aria2c.Aria2c
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject

object Engine {
    sealed interface State {
        object Loading : State
        object Ready : State
        data class Failed(val message: String) : State
    }

    private val _state = MutableStateFlow<State>(State.Loading)
    val state: StateFlow<State> = _state.asStateFlow()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    var aria2Available: Boolean = false
        private set

    fun start(app: Application) {
        _state.value = State.Loading
        scope.launch {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                try {
                    Aria2c.getInstance().init(app)
                    aria2Available = true
                } catch (e: Throwable) {
                    aria2Available = false
                }
                _state.value = State.Ready
            } catch (t: Throwable) {
                _state.value = State.Failed(t.message ?: t.javaClass.simpleName)
            }
        }
    }

    suspend fun awaitReady(): Boolean = state.first { it !is State.Loading } is State.Ready

    private fun notReadyMessage(): String =
        "İndirme motoru hazır değil: " + ((state.value as? State.Failed)?.message ?: "")

    fun version(ctx: Context): String? = try {
        YoutubeDL.getInstance().version(ctx)
    } catch (e: Throwable) {
        null
    }

    suspend fun update(ctx: Context): String = withContext(Dispatchers.IO) {
        if (!awaitReady()) throw IllegalStateException(notReadyMessage())
        val st = YoutubeDL.getInstance().updateYoutubeDL(ctx, YoutubeDL.UpdateChannel.NIGHTLY)
        if (st.toString().contains("ALREADY", ignoreCase = true)) "Motor zaten güncel" else "Motor güncellendi"
    }

    suspend fun fetchInfo(ctx: Context, url: String): MediaInfo = withContext(Dispatchers.IO) {
        if (!awaitReady()) throw IllegalStateException(notReadyMessage())
        val cookies = if (Prefs.useCookies) CookieWriter.write(ctx, listOf(url)) else null
        try {
            val req = YoutubeDLRequest(url)
            req.addOption("--dump-single-json")
            req.addOption("--flat-playlist")
            req.addOption("--no-warnings")
            cookies?.let { req.addOption("--cookies", it.absolutePath) }
            val resp = YoutubeDL.getInstance().execute(request = req)
            parse(url, resp.out)
        } finally {
            cookies?.delete()
        }
    }

    private fun JSONObject.str(k: String): String? {
        if (!has(k) || isNull(k)) return null
        val s = optString(k)
        return if (s.isBlank()) null else s
    }

    private fun thumb(o: JSONObject): String? {
        o.str("thumbnail")?.let { return it }
        val arr = o.optJSONArray("thumbnails") ?: return null
        for (i in arr.length() - 1 downTo 0) {
            val t = arr.optJSONObject(i) ?: continue
            t.str("url")?.let { return it }
        }
        return null
    }

    private fun parse(url: String, out: String): MediaInfo {
        val line = out.lineSequence().map { it.trim() }.lastOrNull { it.startsWith("{") }
            ?: throw IllegalStateException("Bağlantı hakkında bilgi alınamadı")
        val o = JSONObject(line)
        val uploader = o.str("uploader") ?: o.str("channel")

        if (o.optString("_type") == "playlist" || o.has("entries")) {
            val arr = o.optJSONArray("entries")
            val entries = ArrayList<PlaylistEntry>()
            if (arr != null) {
                for (i in 0 until arr.length()) {
                    val e = arr.optJSONObject(i) ?: continue
                    var eu = e.str("url") ?: e.str("webpage_url") ?: continue
                    if (!eu.startsWith("http")) {
                        eu = if (e.optString("ie_key").equals("Youtube", true))
                            "https://www.youtube.com/watch?v=$eu" else continue
                    }
                    entries += PlaylistEntry(eu, e.str("title") ?: eu, thumb(e))
                }
            }
            return MediaInfo(
                url = url,
                title = o.str("title") ?: "Oynatma listesi",
                thumbnail = thumb(o) ?: entries.firstOrNull()?.thumbnail,
                uploader = uploader,
                durationSec = 0,
                heights = emptyList(),
                isPlaylist = true,
                entries = entries
            )
        }

        val heights = LinkedHashSet<Int>()
        val fmts = o.optJSONArray("formats")
        if (fmts != null) {
            for (i in 0 until fmts.length()) {
                val f = fmts.optJSONObject(i) ?: continue
                if (f.isNull("height")) continue
                val h = f.optInt("height", 0)
                if (h > 0) heights += h
            }
        }
        return MediaInfo(
            url = url,
            title = o.str("title") ?: o.str("fulltitle") ?: "video",
            thumbnail = thumb(o),
            uploader = uploader,
            durationSec = if (o.isNull("duration")) 0 else o.optLong("duration", 0),
            heights = heights.toList(),
            isPlaylist = false,
            entries = emptyList()
        )
    }
}
