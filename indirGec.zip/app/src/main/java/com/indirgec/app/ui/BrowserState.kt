package com.indirgec.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.indirgec.app.data.Captured
import org.json.JSONArray
import org.json.JSONTokener

/** Dahili tarayıcı: sayfada oynayan .m3u8 / .mp4 akışlarını yakalar. */
class BrowserState(context: Context) {
    val captured = mutableStateListOf<Captured>()
    var progress by mutableIntStateOf(0)
    var currentUrl by mutableStateOf("")
    var pageTitle by mutableStateOf("")
    var canGoBack by mutableStateOf(false)

    @Volatile
    private var lastPage = ""
    private var defaultUa = ""
    private val main = Handler(Looper.getMainLooper())

    val webView: WebView = WebView(context)

    init {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        s.userAgentString = com.indirgec.app.engine.Engine.BROWSER_UA
        defaultUa = com.indirgec.app.engine.Engine.BROWSER_UA

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString() ?: return false
                return !(u.startsWith("http://") || u.startsWith("https://"))
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (request != null) handle(request)
                return null
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                lastPage = url ?: ""
                currentUrl = url ?: ""
                captured.clear()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                pageTitle = view?.title ?: ""
                canGoBack = view?.canGoBack() ?: false
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                if (url != null) {
                    lastPage = url
                    currentUrl = url
                }
                canGoBack = view?.canGoBack() ?: false
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress = newProgress
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                pageTitle = title ?: ""
            }
        }
        webView.loadUrl("https://www.google.com")
        main.postDelayed({ main.post(poller) }, 3000)
    }

    private fun isStream(u: String): Boolean {
        val l = u.lowercase()
        return l.contains(".m3u8") || l.contains(".mpd")
    }

    /** İndirme için en uygun yakalanan akış: önce HLS/DASH, yoksa sonuncusu. */
    fun best(): Captured? = captured.lastOrNull { isStream(it.url) } ?: captured.lastOrNull()

    private fun addCaptured(u: String, ref: String, ua: String) {
        if (captured.none { it.url == u }) {
            captured.add(Captured(u, ref, ua))
            if (captured.size > 10) captured.removeAt(0)
        }
    }

    private fun handle(request: WebResourceRequest) {
        if (!request.method.equals("GET", ignoreCase = true)) return
        val u = request.url.toString()
        val low = u.lowercase()
        val path = request.url.path?.lowercase() ?: return
        val isMedia = low.contains(".m3u8") || low.contains(".mpd") ||
            path.endsWith(".mp4") || path.endsWith(".webm") || path.endsWith(".mkv") ||
            path.endsWith(".mov") || path.endsWith(".m4v")
        if (!isMedia) return
        val ref = request.requestHeaders?.get("Referer") ?: lastPage
        val ua = request.requestHeaders?.get("User-Agent") ?: defaultUa
        main.post { addCaptured(u, ref, ua) }
    }

    private val pollJs =
        "(function(){var r=[];document.querySelectorAll('video,video source').forEach(function(v){" +
            "var s=v.currentSrc||v.src;if(s&&s.indexOf('http')===0)r.push(s)});return JSON.stringify(r)})()"

    private val poller = object : Runnable {
        override fun run() {
            try {
                webView.evaluateJavascript(pollJs) { res ->
                    try {
                        if (res != null && res != "null") {
                            val inner = JSONTokener(res).nextValue() as? String
                            if (inner != null) {
                                val arr = JSONArray(inner)
                                for (i in 0 until arr.length()) addCaptured(arr.getString(i), lastPage, defaultUa)
                            }
                        }
                    } catch (e: Exception) {
                    }
                }
            } catch (e: Exception) {
            }
            main.postDelayed(this, 2500)
        }
    }

    fun load(raw: String) {
        val t = raw.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(' ') || !t.contains('.') -> "https://www.google.com/search?q=" + Uri.encode(t)
            else -> "https://$t"
        }
        webView.loadUrl(url)
    }

    fun destroy() {
        main.removeCallbacks(poller)
        webView.stopLoading()
        webView.destroy()
    }
}
