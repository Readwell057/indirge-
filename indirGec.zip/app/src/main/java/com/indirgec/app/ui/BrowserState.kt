package com.indirgec.app.ui

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.indirgec.app.data.Captured

/** Dahili tarayıcı: sayfada oynayan .m3u8 / .mp4 akışlarını yakalar. */
class BrowserState(context: Context) {
    val captured = mutableStateListOf<Captured>()
    var progress by mutableIntStateOf(0)
    var currentUrl by mutableStateOf("")
    var pageTitle by mutableStateOf("")
    var canGoBack by mutableStateOf(false)

    @Volatile
    private var lastPage = ""
    private var defaultUa = ""
    private val main = Handler(Looper.getMainLooper())

    val webView: WebView = WebView(context)

    init {
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false
        defaultUa = s.userAgentString ?: ""

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url?.toString() ?: return false
                return !(u.startsWith("http://") || u.startsWith("https://"))
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                if (request != null) handle(request)
                return null
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                lastPage = url ?: ""
                currentUrl = url ?: ""
                captured.clear()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                pageTitle = view?.title ?: ""
                canGoBack = view?.canGoBack() ?: false
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                if (url != null) {
                    lastPage = url
                    currentUrl = url
                }
                canGoBack = view?.canGoBack() ?: false
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                progress = newProgress
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                pageTitle = title ?: ""
            }
        }
        webView.loadUrl("https://www.google.com")
    }

    private fun handle(request: WebResourceRequest) {
        if (!request.method.equals("GET", ignoreCase = true)) return
        val path = request.url.path?.lowercase() ?: return
        val isHls = path.contains(".m3u8")
        val isMp4 = path.endsWith(".mp4")
        if (!isHls && !isMp4) return
        val u = request.url.toString()
        val page = lastPage
        val ua = request.requestHeaders?.get("User-Agent") ?: defaultUa
        main.post {
            if (captured.none { it.url == u }) {
                captured.add(Captured(u, page, ua))
                if (captured.size > 10) captured.removeAt(0)
            }
        }
    }

    fun load(raw: String) {
        val t = raw.trim()
        if (t.isEmpty()) return
        val url = when {
            t.startsWith("http://") || t.startsWith("https://") -> t
            t.contains(' ') || !t.contains('.') -> "https://www.google.com/search?q=" + Uri.encode(t)
            else -> "https://$t"
        }
        webView.loadUrl(url)
    }

    fun destroy() {
        webView.stopLoading()
        webView.destroy()
    }
}
