@file:OptIn(ExperimentalMaterial3Api::class)

package com.indirgec.app.ui

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.indirgec.app.data.DownloadItem
import com.indirgec.app.data.Status
import com.indirgec.app.download.DownloadManager
import com.indirgec.app.formatSize

@Composable
fun DownloadsTab() {
    val items by DownloadManager.items.collectAsState()
    var sub by remember { mutableIntStateOf(0) }
    val active = items.filter { it.isActive }
    val history = items.filter { !it.isActive }.sortedByDescending { it.createdAt }
    val list = if (sub == 0) active else history

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = sub) {
            Tab(selected = sub == 0, onClick = { sub = 0 }, text = { Text("Aktif (${active.size})") })
            Tab(selected = sub == 1, onClick = { sub = 1 }, text = { Text("Geçmiş (${history.size})") })
        }
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            LazyColumn(
                modifier = Modifier.widthIn(max = 720.dp).fillMaxHeight(),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (sub == 1 && history.isNotEmpty()) {
                    item {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                            TextButton(onClick = { DownloadManager.clearHistory() }) { Text("Geçmişi temizle") }
                        }
                    }
                }
                if (sub == 0 && active.isNotEmpty()) {
                    val total = active.sumOf { it.estBytes }
                    if (total > 0) {
                        item {
                            Text(
                                "Tahmini toplam internet kullanımı: " + formatSize(total),
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
                if (list.isEmpty()) {
                    item {
                        Text(
                            if (sub == 0) "Aktif indirme yok." else "Henüz tamamlanan indirme yok.",
                            Modifier.padding(24.dp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                items(list, key = { it.id }) { DownloadCard(it) }
            }
        }
    }
}

@Composable
private fun DownloadCard(item: DownloadItem) {
    val ctx = LocalContext.current
    var confirm by remember { mutableStateOf(false) }
    val pct = (item.progress * 100).toInt()

    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (item.thumbnail != null) {
                    AsyncImage(
                        model = item.thumbnail,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.width(96.dp).height(54.dp).clip(RoundedCornerShape(8.dp))
                    )
                } else {
                    Box(
                        Modifier.width(96.dp).height(54.dp).clip(RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (item.quality.audio) Icons.Filled.MusicNote else Icons.Filled.PlayCircle,
                            null,
                            Modifier.size(32.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(item.title, maxLines = 2, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleSmall)
                    val status = when (item.status) {
                        Status.QUEUED -> "Sırada • ${item.quality.label}" + (if (item.estBytes > 0) " • " + formatSize(item.estBytes) else "")
                        Status.RUNNING -> buildList {
                            add("%$pct")
                            if (item.speed.isNotEmpty()) add(item.speed)
                            if (item.eta.isNotEmpty()) add("kalan ${item.eta}")
                            if (item.estBytes > 0) add(formatSize(item.estBytes))
                        }.joinToString(" • ")
                        Status.PAUSED -> "Duraklatıldı • %$pct" + (if (item.estBytes > 0) " • " + formatSize(item.estBytes) else "")
                        Status.DONE -> "Tamamlandı" + (if (item.estBytes > 0) " • " + formatSize(item.estBytes).removePrefix("~") else "") +
                            " • " + (if (item.quality.audio) "Music/VideoIndirici" else "Movies/VideoIndirici")
                        Status.FAILED -> "Hata: " + (item.error ?: "bilinmiyor")
                        Status.CANCELED -> "İptal edildi"
                    }
                    Text(
                        status,
                        style = MaterialTheme.typography.bodySmall,
                        color = if (item.status == Status.FAILED) MaterialTheme.colorScheme.error
                        else MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            if (item.status == Status.RUNNING || item.status == Status.PAUSED) {
                if (item.status == Status.RUNNING && item.progress <= 0f) {
                    LinearProgressIndicator(Modifier.fillMaxWidth())
                } else {
                    LinearProgressIndicator(progress = { item.progress }, modifier = Modifier.fillMaxWidth())
                }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                when (item.status) {
                    Status.RUNNING, Status.QUEUED -> {
                        IconButton(onClick = { DownloadManager.pause(item.id) }) { Icon(Icons.Filled.Pause, "Duraklat") }
                        IconButton(onClick = { DownloadManager.cancel(item.id) }) { Icon(Icons.Filled.Close, "İptal") }
                    }
                    Status.PAUSED -> {
                        IconButton(onClick = { DownloadManager.resume(item.id) }) { Icon(Icons.Filled.PlayArrow, "Devam et") }
                        IconButton(onClick = { DownloadManager.cancel(item.id) }) { Icon(Icons.Filled.Close, "İptal") }
                    }
                    Status.DONE -> {
                        IconButton(onClick = { openFile(ctx, item) }) { Icon(Icons.Filled.PlayCircle, "Aç") }
                        IconButton(onClick = { shareFile(ctx, item) }) { Icon(Icons.Filled.Share, "Paylaş") }
                        IconButton(onClick = { confirm = true }) { Icon(Icons.Filled.Delete, "Sil") }
                    }
                    Status.FAILED, Status.CANCELED -> {
                        IconButton(onClick = { DownloadManager.resume(item.id) }) { Icon(Icons.Filled.Refresh, "Tekrar dene") }
                        IconButton(onClick = { DownloadManager.remove(item.id, false) }) { Icon(Icons.Filled.Delete, "Kaldır") }
                    }
                }
            }
        }
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text("Kaldır") },
            text = { Text("Bu kaydı listeden kaldırmak mı, dosyayı da cihazdan silmek mi istersin?") },
            confirmButton = {
                TextButton(onClick = { confirm = false; DownloadManager.remove(item.id, true) }) { Text("Dosyayı da sil") }
            },
            dismissButton = {
                Row {
                    TextButton(onClick = { confirm = false; DownloadManager.remove(item.id, false) }) { Text("Sadece listeden") }
                    TextButton(onClick = { confirm = false }) { Text("Vazgeç") }
                }
            }
        )
    }
}

private fun openFile(ctx: android.content.Context, item: DownloadItem) {
    val uri = item.outputUri ?: return
    try {
        val i = Intent(Intent.ACTION_VIEW)
            .setDataAndType(Uri.parse(uri), item.mime ?: "video/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(i)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(ctx, "Dosyayı açacak uygulama bulunamadı", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(ctx, "Dosya açılamadı (silinmiş olabilir)", Toast.LENGTH_SHORT).show()
    }
}

private fun shareFile(ctx: android.content.Context, item: DownloadItem) {
    val uri = item.outputUri ?: return
    try {
        val send = Intent(Intent.ACTION_SEND)
            .setType(item.mime ?: "video/*")
            .putExtra(Intent.EXTRA_STREAM, Uri.parse(uri))
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        ctx.startActivity(Intent.createChooser(send, "Paylaş"))
    } catch (e: Exception) {
        Toast.makeText(ctx, "Paylaşılamadı", Toast.LENGTH_SHORT).show()
    }
}
