@file:OptIn(ExperimentalMaterial3Api::class)

package com.indirgec.app.ui

import android.os.Build
import android.webkit.CookieManager
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Update
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import com.indirgec.app.R

@Composable
fun SettingsTab(vm: MainViewModel) {
    val ctx = LocalContext.current
    Box(Modifier.fillMaxWidth().fillMaxHeight(), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier.widthIn(max = 720.dp).verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Image(
                    painterResource(R.drawable.logo), null,
                    Modifier.size(56.dp).clip(RoundedCornerShape(14.dp))
                )
                Spacer(Modifier.width(12.dp))
                Column {
                    Text("Ayarlar", style = MaterialTheme.typography.headlineSmall)
                    Text("indirGeç 1.0.0", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("İndirme motoru (yt-dlp)", style = MaterialTheme.typography.titleMedium)
                    Text(
                        "Sürüm: " + (vm.engineVersion ?: "—"),
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Button(onClick = { vm.updateEngine() }, enabled = !vm.updating, modifier = Modifier.fillMaxWidth()) {
                        if (vm.updating) {
                            CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Filled.Update, null, Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Text("İndirme Motorunu Güncelle")
                    }
                    vm.updateMessage?.let {
                        Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(
                        "Bir site artık çalışmıyorsa önce motoru güncelle.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("İndirme", style = MaterialTheme.typography.titleMedium)
                    SwitchRow(
                        "Tarayıcı oturumunu kullan",
                        "Dahili tarayıcıda giriş yaptığın Instagram/X hesabının çerezleri indirmelerde kullanılır.",
                        vm.useCookies
                    ) { vm.setCookies(it) }
                    SwitchRow(
                        "aria2c hızlandırıcı",
                        "Çok bağlantılı indirme. Sorun yaşarsan kapat.",
                        vm.useAria2
                    ) { vm.setAria2(it) }
                    OutlinedButton(onClick = {
                        CookieManager.getInstance().removeAllCookies(null)
                        CookieManager.getInstance().flush()
                        Toast.makeText(ctx, "Tarayıcı oturumları temizlendi", Toast.LENGTH_SHORT).show()
                    }) { Text("Tarayıcı oturumlarını temizle") }
                    Text(
                        "Videolar Movies/VideoIndirici, sesler Music/VideoIndirici klasörüne kaydedilir.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Görünüm", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = vm.theme == 0, onClick = { vm.setThemeMode(0) }, label = { Text("Sistem") })
                        FilterChip(selected = vm.theme == 1, onClick = { vm.setThemeMode(1) }, label = { Text("Açık") })
                        FilterChip(selected = vm.theme == 2, onClick = { vm.setThemeMode(2) }, label = { Text("Koyu") })
                    }
                    if (Build.VERSION.SDK_INT >= 31) {
                        SwitchRow("Dinamik renk", "Duvar kâğıdına göre renkler (Material You).", vm.dynamicColor) { vm.setDynamic(it) }
                    }
                }
            }
        }
    }
}

@Composable
private fun SwitchRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.bodyLarge)
            Text(desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Spacer(Modifier.width(12.dp))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
