package com.indirgec.app

import android.app.Application
import com.indirgec.app.download.DownloadManager
import com.indirgec.app.download.Notifications
import com.indirgec.app.engine.Engine

class IndirGecApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        Notifications.createChannels(this)
        DownloadManager.init(this)
        Engine.start(this)
    }
}
