package com.indirgec.app.download

import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.indirgec.app.Prefs
import com.indirgec.app.data.DownloadItem
import com.indirgec.app.data.Quality
import com.indirgec.app.data.Status
import com.indirgec.app.engine.CookieWriter
import com.indirgec.app.engine.Engine
import com.indirgec.app.engine.MediaSaver
import com.indirgec.app.shortError
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

object DownloadManager {
    private lateinit var app: Context
    private val _items = MutableStateFlow<List<DownloadItem>>(emptyList())
    val items: StateFlow<List<DownloadItem>> = _items.asStateFlow()

    private val stops = ConcurrentHashMap<String, Status>()
    private val io = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val ytSpeed = Regex("""at\s+(\S+/s)""")
    private val ariaSpeed = Regex("""DL:(\S+)""")

    fun init(ctx: Context) {
        app = ctx.applicationContext
        val list = try {
            val arr = JSONArray(Prefs.history)
            (0 until arr.length()).map { DownloadItem.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
        _items.value = list.map {
            if (it.status == Status.RUNNING || it.status == Status.QUEUED)
                it.copy(status = Status.PAUSED, speed = "", eta = "")
            else it
        }
    }

    private fun tmpRoot(): File = File(app.getExternalFilesDir(null) ?: app.filesDir, "tmp")

    private fun persist() {
        val list = _items.value
        val trimmed = if (list.size > 300) {
            val done = list.filter { !it.isActive }.sortedBy { it.createdAt }
            val drop = done.take(list.size - 300).map { it.id }.toSet()
            list.filter { it.id !in drop }
        } else list
        val arr = JSONArray()
        trimmed.forEach { arr.put(it.toJson()) }
        Prefs.history = arr.toString()
    }

    private fun update(id: String, persist: Boolean = false, f: (DownloadItem) -> DownloadItem) {
        _items.update { list -> list.map { if (it.id == id) f(it) else it } }
        if (persist) persist()
    }

    private fun find(id: String): DownloadItem? = _items.value.firstOrNull { it.id == id }

    fun setEstimate(id: String, bytes: Long) {
        update(id, true) { it.copy(estBytes = bytes) }
    }

    fun nextQueued(): DownloadItem? = _items.value.firstOrNull { it.status == Status.QUEUED }

    private fun startService() {
        val i = Intent(app, DownloadService::class.java).setAction(DownloadService.ACTION_START)
        ContextCompat.startForegroundService(app, i)
    }

    fun enqueue(newItems: List<DownloadItem>) {
        if (newItems.isEmpty()) return
        _items.update { it + newItems }
        persist()
        startService()
    }

    // ---------- kontrol ----------

    private fun kill(id: String) {
        try {
            YoutubeDL.getInstance().destroyProcessById(id)
        } catch (e: Throwable) {
        }
    }

    fun pause(id: String) {
        val it = find(id) ?: return
        when (it.status) {
            Status.RUNNING -> { stops[id] = Status.PAUSED; kill(id) }
            Status.QUEUED -> update(id, true) { d -> d.copy(status = Status.PAUSED, speed = "", eta = "") }
            else -> {}
        }
    }

    fun cancel(id: String) {
        val it = find(id) ?: return
        when (it.status) {
            Status.RUNNING -> { stops[id] = Status.CANCELED; kill(id) }
            Status.QUEUED, Status.PAUSED -> {
                update(id, true) { d -> d.copy(status = Status.CANCELED, speed = "", eta = "") }
                io.launch { File(tmpRoot(), id).deleteRecursively() }
            }
            else -> {}
        }
    }

    fun resume(id: String) {
        val it = find(id) ?: return
        if (it.status == Status.PAUSED || it.status == Status.FAILED || it.status == Status.CANCELED) {
            update(id, true) { d -> d.copy(status = Status.QUEUED, error = null, speed = "", eta = "") }
            startService()
        }
    }

    fun remove(id: String, deleteFile: Boolean) {
        val it = find(id) ?: return
        if (it.status == Status.RUNNING) {
            stops[id] = Status.CANCELED
            kill(id)
        }
        _items.update { list -> list.filter { x -> x.id != id } }
        persist()
        io.launch {
            File(tmpRoot(), id).deleteRecursively()
            if (deleteFile) it.outputUri?.let { u -> MediaSaver.delete(app, u) }
        }
    }

    fun clearHistory() {
        _items.update { list -> list.filter { it.isActive } }
        persist()
    }

    /** Servis beklenmedik şekilde kapanırsa çalışan indirmeleri duraklat. */
    fun interruptAll() {
        _items.value.filter { it.status == Status.RUNNING }.forEach {
            stops[it.id] = Status.PAUSED
            kill(it.id)
        }
    }

    // ---------- çalıştırma ----------

    private fun fmtEta(sec: Long): String =
        if (sec >= 3600) String.format(Locale.US, "%d:%02d:%02d", sec / 3600, (sec % 3600) / 60, sec % 60)
        else String.format(Locale.US, "%d:%02d", sec / 60, sec % 60)

    private fun onProgress(id: String, p: Float, eta: Long, line: String) {
        val sp = ytSpeed.find(line)?.groupValues?.get(1)
            ?: ariaSpeed.find(line)?.groupValues?.get(1)?.let { "$it/s" }
        update(id) {
            it.copy(
                progress = if (p >= 0f) (p / 100f).coerceIn(0f, 1f) else it.progress,
                speed = sp ?: it.speed,
                eta = if (eta > 0) fmtEta(eta) else it.eta
            )
        }
    }

    private fun buildRequest(item: DownloadItem, tmp: File): YoutubeDLRequest {
        val r = YoutubeDLRequest(item.url)
        r.addOption("--no-playlist")
        r.addOption("--no-mtime")
        r.addOption("--no-warnings")
        r.addOption("--retries", "10")
        r.addOption("--fragment-retries", "10")
        r.addOption("--trim-filenames", "120")
        r.addOption("-P", tmp.absolutePath)
        val base = item.forceName?.replace("%", "%%") ?: "%(title)s"
        r.addOption("-o", "$base.%(ext)s")
        if (item.userAgent != null) {
            r.addOption("--user-agent", item.userAgent)
        } else if (!Engine.isYoutube(item.url)) {
            r.addOption("--user-agent", Engine.BROWSER_UA)
        }
        val ref = item.referer ?: if (Engine.isYoutube(item.url)) null else Engine.origin(item.url)
        ref?.let { r.addOption("--referer", it) }
        item.referer?.let { rr -> Engine.origin(rr)?.let { o -> r.addOption("--add-header", "Origin:" + o.trimEnd('/')) } }

        fun video(h: Int?) {
            val f = if (h == null) "bv*[ext=mp4]+ba[ext=m4a]/bv*+ba/b"
            else "bv*[height<=$h][ext=mp4]+ba[ext=m4a]/bv*[height<=$h]+ba/b[height<=$h]/b"
            r.addOption("-f", f)
            r.addOption("--merge-output-format", "mp4")
        }
        when (item.quality) {
            Quality.BEST -> video(null)
            Quality.P1080 -> video(1080)
            Quality.P720 -> video(720)
            Quality.P480 -> video(480)
            Quality.MP3_192 -> {
                r.addOption("-f", "bestaudio/best"); r.addOption("-x")
                r.addOption("--audio-format", "mp3"); r.addOption("--audio-quality", "192K")
            }
            Quality.MP3_320 -> {
                r.addOption("-f", "bestaudio/best"); r.addOption("-x")
                r.addOption("--audio-format", "mp3"); r.addOption("--audio-quality", "320K")
            }
            Quality.M4A -> {
                r.addOption("-f", "bestaudio[ext=m4a]/bestaudio/best"); r.addOption("-x")
                r.addOption("--audio-format", "m4a")
            }
        }
        if (Prefs.useAria2 && Engine.aria2Available) {
            r.addOption("--downloader", "libaria2c.so")
            r.addOption("--external-downloader-args", "aria2c:-x 16 -s 16 -k 1M --summary-interval=1")
        }
        return r
    }

    private fun pickOutput(dir: File): File? {
        val skip = setOf("part", "ytdl", "temp", "tmp", "json", "frag", "aria2")
        return dir.listFiles()
            ?.filter { it.isFile && it.extension.lowercase() !in skip }
            ?.maxByOrNull { it.length() }
    }

    suspend fun run(item: DownloadItem) {
        withContext(Dispatchers.IO) {
            val id = item.id
            val tmp = File(tmpRoot(), id)
            tmp.mkdirs()
            var cookieFile: File? = null
            update(id, true) { it.copy(status = Status.RUNNING, speed = "", eta = "", error = null) }
            try {
                if (!Engine.awaitReady()) throw IllegalStateException("İndirme motoru hazır değil")
                if (Prefs.useCookies) {
                    cookieFile = CookieWriter.write(app, listOfNotNull(item.url, item.referer))
                }
                val errors = ArrayList<Throwable>()
                var ok = false
                for (a in Engine.attempts(item.url, cookieFile != null)) {
                    val req = buildRequest(item, tmp)
                    a.client?.let { req.addOption("--extractor-args", "youtube:player_client=$it") }
                    if (a.cookies) cookieFile?.let { req.addOption("--cookies", it.absolutePath) }
                    if (stops.containsKey(id)) throw IllegalStateException("stopped")
                    try {
                        YoutubeDL.getInstance().execute(
                            request = req,
                            processId = id,
                            callback = { p, eta, line -> onProgress(id, p, eta, line) }
                        )
                        ok = true
                        break
                    } catch (t: Throwable) {
                        if (stops.containsKey(id) || t is CancellationException) throw t
                        errors += t
                        if (Engine.isYoutube(item.url) && Engine.isFinalError(t)) break
                    }
                }
                if (!ok) throw Engine.pickError(errors)
                if (stops.containsKey(id)) throw IllegalStateException("stopped")
                val out = pickOutput(tmp) ?: throw IllegalStateException("İndirilen dosya bulunamadı")
                val actualBytes = out.length()
                val saved = MediaSaver.save(app, out, item.quality.audio)
                tmp.deleteRecursively()
                update(id, true) {
                    it.copy(
                        status = Status.DONE, progress = 1f, speed = "", eta = "",
                        outputUri = saved.uri, mime = saved.mime, fileName = saved.name, error = null,
                        estBytes = actualBytes
                    )
                }
                Notifications.done(app, item.title, true)
            } catch (t: CancellationException) {
                stops.remove(id)
                update(id, true) { it.copy(status = Status.PAUSED, speed = "", eta = "") }
                throw t
            } catch (t: Throwable) {
                when (stops.remove(id)) {
                    Status.PAUSED -> update(id, true) { it.copy(status = Status.PAUSED, speed = "", eta = "") }
                    Status.CANCELED -> {
                        tmp.deleteRecursively()
                        update(id, true) { it.copy(status = Status.CANCELED, speed = "", eta = "") }
                    }
                    else -> {
                        update(id, true) { it.copy(status = Status.FAILED, speed = "", eta = "", error = shortError(t)) }
                        Notifications.done(app, item.title, false)
                    }
                }
            } finally {
                cookieFile?.delete()
                stops.remove(id)
            }
        }
    }
}
