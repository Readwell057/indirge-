@file:OptIn(ExperimentalMaterial3Api::class)

package com.indirgec.app.ui

import android.app.Application
import androidx.compose.foundation.Image
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.indirgec.app.R
import com.indirgec.app.data.MediaInfo
import com.indirgec.app.data.Quality
import com.indirgec.app.engine.Engine
import com.indirgec.app.formatDuration

@Composable
fun DownloadTab(vm: MainViewModel) {
    val ctx = LocalContext.current
    val engine by Engine.state.collectAsState()
    val clipboard = LocalClipboardManager.current
    val focus = LocalFocusManager.current
    val state = vm.fetchState

    Box(Modifier.fillMaxWidth().fillMaxHeight(), contentAlignment = Alignment.TopCenter) {
        LazyColumn(
            modifier = Modifier.widthIn(max = 720.dp).fillMaxHeight(),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(R.drawable.logo),
                        contentDescription = "indirGeç",
                        modifier = Modifier.size(56.dp).clip(RoundedCornerShape(14.dp))
                    )
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("indirGeç", style = MaterialTheme.typography.headlineSmall)
                        Text(
                            "Bağlantıyı yapıştır, indir, geç.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }

            item {
                when (val e = engine) {
                    is Engine.State.Loading -> Card(Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                            Spacer(Modifier.width(12.dp))
                            Text("İndirme motoru hazırlanıyor…")
                        }
                    }
                    is Engine.State.Failed -> Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text("Motor başlatılamadı: ${e.message}", color = MaterialTheme.colorScheme.onErrorContainer)
                            TextButton(onClick = { Engine.start(ctx.applicationContext as Application) }) {
                                Text("Yeniden dene")
                            }
                        }
                    }
                    else -> {}
                }
            }

            item {
                OutlinedTextField(
                    value = vm.urlInput,
                    onValueChange = { vm.urlInput = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Video veya liste bağlantısı") },
                    singleLine = true,
                    leadingIcon = { Icon(Icons.Filled.Link, null) },
                    trailingIcon = {
                        if (vm.urlInput.isNotEmpty()) {
                            IconButton(onClick = { vm.urlInput = ""; vm.reset() }) {
                                Icon(Icons.Filled.Clear, "Temizle")
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go, keyboardType = KeyboardType.Uri),
                    keyboardActions = KeyboardActions(onGo = { focus.clearFocus(); vm.fetch() })
                )
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = {
                        val t = clipboard.getText()?.text
                        if (!t.isNullOrBlank()) vm.onSharedText(t)
                    }) {
                        Icon(Icons.Filled.ContentPaste, null, Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Yapıştır")
                    }
                    Button(
                        onClick = { focus.clearFocus(); vm.fetch() },
                        enabled = state !is FetchState.Loading
                    ) { Text("Getir") }
                }
            }

            when (state) {
                is FetchState.Loading -> item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(24.dp), strokeWidth = 2.dp)
                        Spacer(Modifier.width(12.dp))
                        Text("Bilgiler alınıyor…")
                    }
                }
                is FetchState.Error -> item {
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer)
                    ) {
                        Text(
                            state.msg,
                            Modifier.padding(12.dp),
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
                is FetchState.Ready -> {
                    val info = state.info
                    item { InfoCard(info) }
                    item {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            QualityRow(
                                "Video",
                                listOf(Quality.BEST, Quality.P1080, Quality.P720, Quality.P480),
                                vm.quality
                            ) { vm.quality = it }
                            QualityRow(
                                "Ses",
                                listOf(Quality.MP3_192, Quality.MP3_320, Quality.M4A),
                                vm.quality
                            ) { vm.quality = it }
                        }
                    }
                    item {
                        Button(onClick = { vm.download() }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Filled.Download, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                if (info.isPlaylist) "Seçilenleri indir (${vm.selected.size})" else "İndir"
                            )
                        }
                    }
                    if (info.isPlaylist) {
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(
                                    checked = vm.selected.size == info.entries.size && info.entries.isNotEmpty(),
                                    onCheckedChange = { vm.setAll(info, it) }
                                )
                                Text("Tümünü seç (${info.entries.size} video)")
                            }
                        }
                        itemsIndexed(info.entries, key = { i, e -> "$i-${e.url}" }) { _, e ->
                            Row(
                                Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = e.url in vm.selected,
                                    onCheckedChange = { vm.toggleEntry(e.url) }
                                )
                                if (e.thumbnail != null) {
                                    AsyncImage(
                                        model = e.thumbnail,
                                        contentDescription = null,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.width(80.dp).aspectRatio(16f / 9f).clip(RoundedCornerShape(6.dp))
                                    )
                                    Spacer(Modifier.width(8.dp))
                                }
                                Text(
                                    e.title,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
                else -> {}
            }
        }
    }
}

@Composable
private fun InfoCard(info: MediaInfo) {
    Card(Modifier.fillMaxWidth()) {
        Column {
            if (info.thumbnail != null) {
                AsyncImage(
                    model = info.thumbnail,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
                )
            }
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(info.title, style = MaterialTheme.typography.titleMedium, maxLines = 3, overflow = TextOverflow.Ellipsis)
                val meta = ArrayList<String>()
                if (info.isPlaylist) meta += "Oynatma listesi • ${info.entries.size} video"
                info.uploader?.let { meta += it }
                if (info.durationSec > 0) meta += formatDuration(info.durationSec)
                if (meta.isNotEmpty()) {
                    Text(meta.joinToString(" • "), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                if (info.heights.isNotEmpty()) {
                    Text(
                        "Mevcut kaliteler: " + info.heights.sortedDescending().joinToString(", ") { "${it}p" },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun QualityRow(title: String, options: List<Quality>, selected: Quality, onSelect: (Quality) -> Unit) {
    Column {
        Text(title, style = MaterialTheme.typography.labelLarge)
        Row(
            Modifier.horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            options.forEach { q ->
                FilterChip(selected = q == selected, onClick = { onSelect(q) }, label = { Text(q.label) })
            }
        }
    }
}
