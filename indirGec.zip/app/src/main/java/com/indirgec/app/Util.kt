package com.indirgec.app

import java.util.Locale

fun shortError(t: Throwable): String {
    val msg = t.message ?: t.javaClass.simpleName
    val lines = msg.lines().map { it.trim() }.filter { it.isNotEmpty() }
    val line = lines.lastOrNull { it.startsWith("ERROR", ignoreCase = true) }
        ?: lines.firstOrNull()
        ?: msg
    return line.take(300)
}

private val URL_REGEX = Regex("""https?://[^\s]+""", RegexOption.IGNORE_CASE)

fun extractUrl(text: String): String? {
    val m = URL_REGEX.find(text)
    if (m != null) return m.value.trimEnd(')', ']', '.', ',', ';', '"', '\'')
    val t = text.trim()
    if (t.isNotEmpty() && !t.contains(' ') && t.contains('.')) return "https://$t"
    return null
}

fun formatDuration(sec: Long): String {
    if (sec <= 0) return ""
    val h = sec / 3600
    val m = (sec % 3600) / 60
    val s = sec % 60
    return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, s)
    else String.format(Locale.US, "%d:%02d", m, s)
}

fun sanitizeFileName(s: String): String =
    s.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().take(100).ifBlank { "video" }
