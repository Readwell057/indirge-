package com.indirgec.app.data

import org.json.JSONObject

enum class Quality(val label: String, val audio: Boolean) {
    BEST("En İyi Kalite", false),
    P1080("1080p MP4", false),
    P720("720p MP4", false),
    P480("480p MP4", false),
    MP3_192("MP3 192 kbps", true),
    MP3_320("MP3 320 kbps", true),
    M4A("M4A", true)
}

enum class Status { QUEUED, RUNNING, PAUSED, DONE, FAILED, CANCELED }

data class DownloadItem(
    val id: String,
    val url: String,
    val title: String,
    val thumbnail: String? = null,
    val quality: Quality = Quality.BEST,
    val status: Status = Status.QUEUED,
    val progress: Float = 0f,
    val speed: String = "",
    val eta: String = "",
    val outputUri: String? = null,
    val mime: String? = null,
    val fileName: String? = null,
    val error: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val forceName: String? = null,
    val referer: String? = null,
    val userAgent: String? = null,
    val estBytes: Long = 0
) {
    val isActive: Boolean
        get() = status == Status.QUEUED || status == Status.RUNNING || status == Status.PAUSED

    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("url", url)
        put("title", title)
        put("thumbnail", thumbnail)
        put("quality", quality.name)
        put("status", status.name)
        put("progress", progress.toDouble())
        put("outputUri", outputUri)
        put("mime", mime)
        put("fileName", fileName)
        put("error", error)
        put("createdAt", createdAt)
        put("forceName", forceName)
        put("referer", referer)
        put("userAgent", userAgent)
        put("estBytes", estBytes)
    }

    companion object {
        private fun JSONObject.str(k: String): String? =
            if (has(k) && !isNull(k)) getString(k) else null

        fun fromJson(o: JSONObject): DownloadItem = DownloadItem(
            id = o.getString("id"),
            url = o.getString("url"),
            title = o.optString("title", "video"),
            thumbnail = o.str("thumbnail"),
            quality = try { Quality.valueOf(o.optString("quality", "BEST")) } catch (e: Exception) { Quality.BEST },
            status = try { Status.valueOf(o.optString("status", "FAILED")) } catch (e: Exception) { Status.FAILED },
            progress = o.optDouble("progress", 0.0).toFloat(),
            outputUri = o.str("outputUri"),
            mime = o.str("mime"),
            fileName = o.str("fileName"),
            error = o.str("error"),
            createdAt = o.optLong("createdAt", System.currentTimeMillis()),
            forceName = o.str("forceName"),
            referer = o.str("referer"),
            userAgent = o.str("userAgent"),
            estBytes = o.optLong("estBytes", 0)
        )
    }
}

data class PlaylistEntry(val url: String, val title: String, val thumbnail: String?, val durationSec: Long = 0)

data class FormatInfo(
    val height: Int,
    val hasVideo: Boolean,
    val hasAudio: Boolean,
    val sizeBytes: Long,
    val tbr: Double
)

data class MediaInfo(
    val url: String,
    val title: String,
    val thumbnail: String?,
    val uploader: String?,
    val durationSec: Long,
    val heights: List<Int>,
    val isPlaylist: Boolean,
    val entries: List<PlaylistEntry>,
    val formats: List<FormatInfo> = emptyList()
)

data class Captured(val url: String, val referer: String, val userAgent: String)
