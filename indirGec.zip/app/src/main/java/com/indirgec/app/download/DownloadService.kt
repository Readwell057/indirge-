package com.indirgec.app.download

import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/** İndirmeleri ekran kapalıyken / uygulama arka plandayken de sürdüren ön plan servisi (dataSync). */
class DownloadService : Service() {

    companion object {
        const val ACTION_START = "com.indirgec.app.START"
        const val ACTION_CANCEL = "com.indirgec.app.CANCEL"
        const val EXTRA_ID = "id"
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Any()
    private var running = false
    private var ticker: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) {
            intent.getStringExtra(EXTRA_ID)?.let { DownloadManager.cancel(it) }
            return START_NOT_STICKY
        }
        try {
            goForeground()
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        synchronized(lock) {
            if (!running) {
                running = true
                startTicker()
                scope.launch { worker() }
            }
        }
        return START_NOT_STICKY
    }

    private fun goForeground() {
        val n = Notifications.progress(this, DownloadManager.items.value)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(Notifications.ID_PROGRESS, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(Notifications.ID_PROGRESS, n)
        }
    }

    private fun startTicker() {
        val nm = getSystemService(NotificationManager::class.java)
        ticker = scope.launch {
            while (isActive) {
                synchronized(lock) {
                    if (running) {
                        nm.notify(Notifications.ID_PROGRESS, Notifications.progress(this@DownloadService, DownloadManager.items.value))
                    }
                }
                delay(1000)
            }
        }
    }

    private suspend fun worker() {
        while (true) {
            val next = DownloadManager.nextQueued()
            if (next == null) {
                val finished = synchronized(lock) {
                    if (DownloadManager.nextQueued() == null) {
                        running = false
                        ticker?.cancel()
                        stopForeground(true)
                        stopSelf()
                        true
                    } else false
                }
                if (finished) return else continue
            }
            DownloadManager.run(next)
        }
    }

    override fun onDestroy() {
        DownloadManager.interruptAll()
        scope.cancel()
        super.onDestroy()
    }
}
