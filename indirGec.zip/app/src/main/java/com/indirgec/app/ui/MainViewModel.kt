package com.indirgec.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.indirgec.app.Prefs
import com.indirgec.app.data.Captured
import com.indirgec.app.data.DownloadItem
import com.indirgec.app.data.MediaInfo
import com.indirgec.app.data.Quality
import com.indirgec.app.download.DownloadManager
import com.indirgec.app.engine.Engine
import com.indirgec.app.extractUrl
import com.indirgec.app.sanitizeFileName
import com.indirgec.app.shortError
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

sealed interface FetchState {
    object Idle : FetchState
    object Loading : FetchState
    data class Error(val msg: String) : FetchState
    data class Ready(val info: MediaInfo) : FetchState
}

class MainViewModel(app: Application) : AndroidViewModel(app) {
    var tab by mutableIntStateOf(0)
    var urlInput by mutableStateOf("")
    var fetchState by mutableStateOf<FetchState>(FetchState.Idle)
    var quality by mutableStateOf(Quality.BEST)
    val selected = mutableStateListOf<String>()
    var message by mutableStateOf<String?>(null)
    var pendingBrowserUrl by mutableStateOf<String?>(null)

    var theme by mutableIntStateOf(Prefs.theme)
    var dynamicColor by mutableStateOf(Prefs.dynamicColor)
    var useCookies by mutableStateOf(Prefs.useCookies)
    var useAria2 by mutableStateOf(Prefs.useAria2)

    var engineVersion by mutableStateOf<String?>(null)
    var updating by mutableStateOf(false)
    var updateMessage by mutableStateOf<String?>(null)

    init {
        refreshVersion()
    }

    fun setThemeMode(v: Int) { theme = v; Prefs.theme = v }
    fun setDynamic(v: Boolean) { dynamicColor = v; Prefs.dynamicColor = v }
    fun setCookies(v: Boolean) { useCookies = v; Prefs.useCookies = v }
    fun setAria2(v: Boolean) { useAria2 = v; Prefs.useAria2 = v }

    fun openInBrowser(url: String) {
        pendingBrowserUrl = url
    }

    fun openGoogleLogin() {
        openInBrowser("https://accounts.google.com/ServiceLogin?service=youtube&continue=https%3A%2F%2Fm.youtube.com%2F")
    }

    fun reset() {
        fetchState = FetchState.Idle
        selected.clear()
    }

    fun onSharedText(text: String) {
        val link = extractUrl(text) ?: return
        urlInput = link
        tab = 0
        fetch()
    }

    fun fetch() {
        val link = extractUrl(urlInput)
        if (link == null) {
            fetchState = FetchState.Error("Geçerli bir bağlantı gir")
            return
        }
        urlInput = link
        fetchState = FetchState.Loading
        viewModelScope.launch {
            try {
                val info = Engine.fetchInfo(getApplication<Application>(), link)
                selected.clear()
                selected.addAll(info.entries.map { it.url })
                fetchState = FetchState.Ready(info)
            } catch (t: Throwable) {
                fetchState = FetchState.Error(shortError(t))
            }
        }
    }

    fun toggleEntry(url: String) {
        if (url in selected) selected.remove(url) else selected.add(url)
    }

    fun setAll(info: MediaInfo, on: Boolean) {
        selected.clear()
        if (on) selected.addAll(info.entries.map { it.url })
    }

    private fun newItem(url: String, title: String, thumb: String?) = DownloadItem(
        id = UUID.randomUUID().toString(),
        url = url,
        title = title,
        thumbnail = thumb,
        quality = quality
    )

    fun download() {
        val s = fetchState as? FetchState.Ready ?: return
        val info = s.info
        val list = if (info.isPlaylist) {
            val sel = selected.toSet()
            info.entries.filter { it.url in sel }.map { newItem(it.url, it.title, it.thumbnail) }
        } else {
            listOf(newItem(info.url, info.title, info.thumbnail))
        }
        if (list.isEmpty()) {
            message = "Önce en az bir video seç"
            return
        }
        DownloadManager.enqueue(list)
        message = "${list.size} indirme sıraya eklendi"
        tab = 2
    }

    fun downloadCaptured(c: Captured, pageTitle: String) {
        val title = pageTitle.ifBlank { "video" }
        val item = DownloadItem(
            id = UUID.randomUUID().toString(),
            url = c.url,
            title = title,
            quality = Quality.BEST,
            forceName = sanitizeFileName(title),
            referer = c.referer.ifBlank { null },
            userAgent = c.userAgent.ifBlank { null }
        )
        DownloadManager.enqueue(listOf(item))
        message = "Yakalanan medya indirme sırasına eklendi"
    }

    fun refreshVersion() {
        viewModelScope.launch {
            if (Engine.awaitReady()) {
                engineVersion = withContext(Dispatchers.IO) { Engine.version(getApplication<Application>()) }
            }
        }
    }

    fun updateEngine() {
        if (updating) return
        updating = true
        updateMessage = null
        viewModelScope.launch {
            try {
                updateMessage = Engine.update(getApplication<Application>())
                refreshVersion()
            } catch (t: Throwable) {
                updateMessage = "Güncelleme başarısız: " + shortError(t)
            } finally {
                updating = false
            }
        }
    }
}
