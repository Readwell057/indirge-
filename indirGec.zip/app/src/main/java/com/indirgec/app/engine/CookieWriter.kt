package com.indirgec.app.engine

import android.content.Context
import android.net.Uri
import android.webkit.CookieManager
import java.io.File

/** Dahili tarayıcının (WebView) çerezlerini yt-dlp için Netscape formatında dosyaya yazar. */
object CookieWriter {

    fun write(ctx: Context, urls: List<String>): File? {
        val cm = CookieManager.getInstance()
        val hosts = linkedSetOf<String>()
        for (u in urls) {
            val host = try { Uri.parse(u).host } catch (e: Exception) { null } ?: continue
            hosts += host
            val base = baseDomain(host)
            hosts += base
            when (base) {
                "x.com" -> hosts += "twitter.com"
                "twitter.com" -> hosts += "x.com"
                "youtube.com", "youtu.be" -> { hosts += "youtube.com"; hosts += "google.com" }
            }
        }
        val expiry = System.currentTimeMillis() / 1000 + 365L * 24 * 3600
        val seen = HashSet<String>()
        val lines = ArrayList<String>()
        for (h in hosts) {
            val raw = cm.getCookie("https://$h") ?: continue
            val domain = "." + baseDomain(h)
            for (part in raw.split(";")) {
                val p = part.trim()
                val idx = p.indexOf('=')
                if (idx <= 0) continue
                val name = p.substring(0, idx)
                val value = p.substring(idx + 1)
                if (!seen.add("$domain|$name")) continue
                lines += "$domain\tTRUE\t/\tTRUE\t$expiry\t$name\t$value"
            }
        }
        if (lines.isEmpty()) return null
        val f = File(ctx.cacheDir, "cookies_${System.nanoTime()}.txt")
        f.writeText("# Netscape HTTP Cookie File\n" + lines.joinToString("\n") + "\n")
        return f
    }

    private fun baseDomain(host: String): String {
        val parts = host.split(".")
        if (parts.size <= 2) return host
        val last = parts[parts.size - 1]
        val second = parts[parts.size - 2]
        return if (last.length == 2 && second.length <= 3) parts.takeLast(3).joinToString(".")
        else parts.takeLast(2).joinToString(".")
    }
}
