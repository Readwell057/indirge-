# indirGeç

Android (telefon + tablet) video/ses indirici. Kotlin, Jetpack Compose, Material 3, yt-dlp (youtubedl-android).

## APK alma
1. Bu klasörün İÇİNDEKİ her şeyi (`.github` dahil) GitHub'da yeni bir repoya yükle (`main` dalı).
   `.github` klasörü görünmediyse: Add file > Create new file > `.github/workflows/build-apk.yml` yolunu yazıp `build-apk.yml` içeriğini yapıştır.
2. Repo > Actions > "Build APK" > Run workflow (push'ta da otomatik çalışır).
3. Bitince çalıştırmanın altındaki Artifacts > `indirGec-debug-apk` indir, zip'ten `app-debug.apk` çıkar ve kur.
